# PSIRENS - Plotted Satellite Inclination and Raan ENgagement Screening

A server-archetype dashboard for the Bluestaq App Store. It ingests UDL element
sets (including exercise tracks), computes each object's sub-satellite longitude
and inclination at every elset epoch, and renders the GEO belt as a longitude vs
inclination plot: historic trails, drift-direction heads sized by drift rate,
and dashed links to each object's labelled target.

Classification: Not Classified (owner-confirmed, 20 July 2026).

## Data modes and hero tabs

Ingests four UDL data modes: REAL, SIMULATED, TEST, EXERCISE. Two hero tabs:
- Real World - REAL only.
- Combined (Real + SIM) - all four modes, with per-mode toggle chips.

## Run locally

```
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt -r requirements-dev.txt
python -m pytest -q                          # 39 tests, coverage >= 80%
PYTHONPATH=src python -m uvicorn psirens.main:app --port 8080
```
With no `UDL_BASE_URL` set the app runs the offline demo belt. Point it at a
tenant by setting the UDL variables in the environment.

## Data sources

- UDL element sets (`UDLElsetSource`). All wire details are TBC and env-
  overridable; see the verification list below.
- Manual temporary elsets (`POST /api/manual-elset`), carrying an explicit
  target and a TTL. Deleted elsets leave the plot immediately.
- Deterministic demo belt (`DemoElsetSource`) for the offline test/CI path.

## Endpoints

`GET /` (SPA), `GET /healthz` (real-write probe, errno in the 503 body),
`GET /readyz`, `GET /api/tracks?view=real|combined&modes=...` (ETag/304),
`GET /api/meta`, `POST /api/manual-elset`, `DELETE /api/manual-elset/{id}`,
`POST /api/refresh`. State-changing routes are token-gated when `TEAM_TOKEN`
is set; reads of the belt data are open (Not Classified).

## App Store deploy

```
sh simulate-pipeline.sh 1.0.0   # reproduces the platform test stage, green
sh package-appstore.sh 1.0.0    # flat upload zip (Dockerfile at root)
```
Runtime contract: reads `PORT` (default 8080), binds 0.0.0.0, `GET /` and
`/healthz` return 200 unauthenticated, runs as non-root uid 10001, image
flattened to a single layer. The operator Environment Variables tab stays
EMPTY for a code-defaults run. The FILE_STORAGE add-on mounts `/data`
(`STORAGE_MOUNT_PATH`); a non-root container using it needs an operations
request to set `securityContext.fsGroup`.

## Owner verification list (TBC before live UDL use)

The LEARNED register only verifies `/udl/eoobservation`; nothing about
`/udl/elset` is assumed. Confirm against the tenant and set the matching env:
- `UDL_ELSET_PATH` - the elset endpoint path.
- `UDL_EPOCH_PARAM` and the epoch range syntax the endpoint accepts.
- `UDL_ACCEPT` - whether the list endpoint needs a non-JSON Accept header.
- `UDL_TARGET_FIELD` - which labelled field carries the intended target
  (default `tags`). This is the single most load-bearing unknown.
- The `dataMode` tokens present in tenant data, and the field names/units for
  the returned elements.
